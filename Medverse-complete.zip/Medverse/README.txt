Open Medverse.html in your browser to use the complete offline site.

To edit the site, use dist/index.html, dist/styles.css and dist/app.js. The assets folder contains the images and PDF library with its license. Open dist/index.html to try your edits. The standalone HTML is a separate snapshot.

Patient records are saved in the browser used to enter them. The examples folder contains synthetic records.
